#ifndef STOPNOTIFYING_H
#define STOPNOTIFYING_H
class StopNotifying {};
#endif