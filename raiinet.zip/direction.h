#ifndef DIRECTION_H
#define DIRECTION_H

enum class Direction
{
    Up,
    Down,
    Left,
    Right
};

#endif